import os
import json
from pprint import pprint

# I can open the json file
# Using with opens and closes the file. See: http://effbot.org/zone/python-with-statement.htm
with open('graphImageList.json') as data_file:
    data = json.load(data_file)

for i in data:
    print ("i", i)
    for j in data[i]:
        # j["newPath"]=[]
        # https://stackoverflow.com/questions/521674/initializing-a-list-to-a-known-number-of-elements-in-python
        j["newPath"]=["modules/graphQuestions/graphImages/color/rangerPoseGreen.png"] * 3
        pprint(j)
        print(j["title"])

# pprint(data)
pprint(data["line"][0])

# I can a list of the directory image files.

F = open("./graphList.json", "r")
print ("pot")
# print (F.read())

# fileNames = filter(lambda x: x.endswith('.txt'), os.listdir('mydir'))
fileNames = os.listdir("./graphImages/color")
print("fileNames", fileNames)

# A method using endswith to fileter out the png
# txt_files = list(filter(lambda x: x.endswith('.png'), os.listdir('.')))
# print("using endswith and .png", txt_files)

# Showing what happens if path doesnot have a name.
# stuff = os.path.splitext(".json")
# print (stuff)

txt_files2 = list(filter(lambda x: os.path.splitext(x)[1]==".png", os.listdir('.')))
print("using splittext and .json", txt_files2)

# Not super familiar with this but it seems like a condensed for in loop with a if statement
# Why use x twice? http://www.pythonforbeginners.com/basics/list-comprehensions-in-python
# something = ( x for x in fileNames if x.endswith('.png') )
# print ("using for in and if and .json", list(something))

graphTypes = ("line", "pie", "bar")
emType = ("embellished", "normal", "unrelated")
# I need to get the key of each file and check the image list... should make a dictionary ...
# If path includes line => go lines, if includes embellished => 0 or something like that
# Cycle through all filenames and place as you go
for x in fileNames:
    print ("xNew", x)
    print ("\n")
    for i in graphTypes:
        print ("g", i)
        if i in x:
            print ("iCaught: ", x)
            # pprint (data[i])
            for j in data[i]:
                if j["key"] in x:
                    # https://stackoverflow.com/questions/15684605/python-for-loop-get-indexs
                    for ind, k in enumerate(emType):
                        if k in x:
                            print ("iCaught a : ", j["key"])
                            j["newPath"][ind] = "modules/graphQuestions/graphImages/color/"+x
                            # j["newPath"] = j["newPath"] + [x]

# Print the new object
print("newData is: ")
for i in data:
    for j in data[i]:
        pprint(j["newPath"])

print("\n")
pprint(data["line"][0]["newPath"][2])
# pprint(data["bar"])

# Write the new object
# https://www.safaribooksonline.com/library/view/python-cookbook-3rd/9781449357337/ch06s02.html
# Writing JSON data
with open('data.json', 'w') as f:
     json.dump(data, f)
